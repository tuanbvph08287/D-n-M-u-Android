package com.example.bookmanager_tuanbvph08287;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class TrangChuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trangchu);
        setTitle("QUẢN LÝ SÁCH");

    }

}
